// Namespaces used by almost every file in the infrastructure layer.
global using Microsoft.EntityFrameworkCore;
global using Microsoft.Extensions.Logging;
global using StudyConnect.Core.Abstractions;
global using StudyConnect.Core.Common;
global using StudyConnect.Core.Entities;
global using StudyConnect.Core.Enums;
global using StudyConnect.Core.Extensions;
global using StudyConnect.Core.Matching;
global using StudyConnect.Core.Models;
global using StudyConnect.Infrastructure.Data;
